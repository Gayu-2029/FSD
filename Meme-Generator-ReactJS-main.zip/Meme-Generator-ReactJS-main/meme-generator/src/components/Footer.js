function Footer() {
    return (
        <footer>
            <p>
                Created with ❤️ by &nbsp;
                <a className="website-link" href="https://linktr.ee/hmjatt">
                    Harmeet Matharoo
                </a>
            </p>
        </footer>
    );
}

export default Footer;
